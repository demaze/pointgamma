<?php
function display() {
    echo "<img alt='logo' src='images/logo.png' class='center animated fadeIn'>";
}
?>